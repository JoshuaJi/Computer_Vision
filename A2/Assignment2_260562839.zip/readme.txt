Please put the img_align_celeba folder the same level as the ipynb file
