Time cost:

Q1. 5 seconds
Q2.
    a) 2 mins
    b) 2 mins
    c) 1.5 mins
